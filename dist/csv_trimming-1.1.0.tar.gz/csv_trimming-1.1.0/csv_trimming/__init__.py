"""Package for cleaning & trimming CSV files."""

from csv_trimming.trim import CSVTrimmer

__all__ = ["CSVTrimmer"]
