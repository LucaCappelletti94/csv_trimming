from .trim import CSVTrimmer

__all__ = [
    "CSVTrimmer"
]
