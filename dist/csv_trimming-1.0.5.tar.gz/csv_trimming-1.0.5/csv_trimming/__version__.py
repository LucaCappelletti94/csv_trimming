"""Current version of package csv_trimming"""
__version__ = "1.0.5"